# Scheletro progetto Java

<div align="center">
  <b>Progetto dell’insegnamento di Laboratorio di Programmazione ad Oggetti</b>
  <br>
  <b>A.A. 2020/2021</b>
  <br>
  <b>Corso di Laurea in Informatica</b>
  <br>
  <b>Università degli studi dell'Aquila</b>
  <br>
  <b>Docente: Dott. Amleto Di Salle</b>
</div>


